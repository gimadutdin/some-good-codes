//---------------------------------------------------------------------------

#ifndef BrH
#define BrH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include "SHDocVw_OCX.h"
#include <OleCtrls.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TPageControl *PageControl1;
        TButton *Button1;
        TEdit *Edit1;
        TButton *Button2;
        TTabSheet *TabSheet1;
        TCppWebBrowser *CppWebBrowser1;
        TButton *Button3;
        TButton *Button4;
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall CppWebBrowser1NewWindow2(TObject *Sender,
          LPDISPATCH *ppDisp, VARIANT_BOOL *Cancel);
        void __fastcall CppWebBrowser1StatusTextChange(TObject *Sender,
          BSTR URL);
        void __fastcall Button3Click(TObject *Sender);
        void __fastcall FormResize(TObject *Sender);
        void __fastcall Button4Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
