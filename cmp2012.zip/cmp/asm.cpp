//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <vcl.h>
#include <stdio.h>
#pragma hdrstop

#include "asm.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
AnsiString text="";
AnsiString t = "";
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

AnsiString code(TStringList * lst, int x) {
if (lst->Strings[x]=="prt") {
ShowMessage(lst->Strings[x+1]);
AnsiString msg1 = "echo invoke  MessageBox,NULL,'"+lst->Strings[x+1]+"','"+lst->Strings[x+1]+"',MB_OK>>m.asm";
system(msg1.c_str());
}
};

AnsiString pars(AnsiString txt) {
system("echo format PE GUI 4.0>>m.asm");
system("echo entry start ;>>m.asm" );
system("echo include 'INCLUDE\\win32ax.inc'>>m.asm");
system("echo start:>>m.asm");

TStringList * list = new TStringList(); //���������
list->Delimiter = ';';                 //���������� ����������� (�� ��������� - ������)
list->DelimitedText = txt;//��������� ������
for (int i=0;i<list->Count-1;i++) {
code(list,i);
}
system("echo invoke  ExitProcess,0>>m.asm");
system("echo data    import>>m.asm");
system("echo library kernel32,'kernel32.dll',user32,'user32.dll'\>>m.asm");
system("echo include 'INCLUDE\\api/kernel32.inc'>>m.asm");
system("echo include 'INCLUDE\\api/user32.inc'>>m.asm");
system("echo end     data>>m.asm");
};

void __fastcall TForm1::Button2Click(TObject *Sender)
{
ShellExecute(0,"","FASM.EXE","m.asm",0,SW_HIDE);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
if (FileExists("m.asm")) {
DeleteFile("m.asm");
}
text = "";
for (int i=0;i<Memo1->Lines->Count;i++) {
text += Memo1->Lines->Strings[i];
}

pars(text);
}
//---------------------------------------------------------------------------

