﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
    }
}

namespace Vector2D_operations
{
    public class Vector2D
    {
        public double x { get; set; }        
        public double y { get; set; }
 
        public Vector2D()
        {
            this.x = 0;
            this.y = 0;
        }
        public Vector2D(double x, double y)
        {
            this.x = x;
            this.y = y;
        }
 
        public static Vector2D operator +(Vector2D v1, Vector2D v2)           // сложение векторов
        {
            return new Vector2D(v1.x + v2.x, v1.y + v2.y);
        }
        public static Vector2D operator -(Vector2D v1, Vector2D v2)           // Разность векторов
        {
            return new Vector2D(v1.x - v2.x, v1.y - v2.y);
        }
       public static Vector2D operator +(Vector2D V1, double v2)              // Сложение Вектора и числа
        {
            return new Vector2D(V1.x + v2, V1.y + v2);
        }
        public static Vector2D operator -(Vector2D V1, double v2)               // Разность вектора и числа
        {
            return new Vector2D(V1.x - v2, V1.y - v2);
        }
        public static Vector2D operator *(Vector2D v1, double v2)                    // Умножение вектора на число
        {
            return new Vector2D(v1.x * v2, v1.y * v2);
        }
        public static bool operator ==(Vector2D v1, Vector2D v2)           
        {
            return v1.x == v2.x && v1.y == v2.y;
        }
        public static bool operator !=(Vector2D v1, Vector2D v2)           
        {
            return v1.x != v2.x || v1.y != v2.y;
        }
        public static double dot_prod(Vector2D v1, Vector2D v2)
        {
            return v1.x*v2.x + v1.y*v2.y;
        }
        public static double cross_prod(Vector2D v1, Vector2D v2)
        {
            return v1.x*v2.y - v2.x*v1.y;
        }
        public static int rnd(int x)
        {
            Random r = new Random(123);
            return 20 + r.Next(x);
        }
        
        public static string ShowDialog(string text, string caption)
        {
            Form prompt = new Form()
            {
                Width = 500,
                Height = 150,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = caption,
                StartPosition = FormStartPosition.CenterScreen
            };
            Label textLabel = new Label() { Left = 50, Top=20, Text=text };
            TextBox textBox = new TextBox() { Left = 50, Top=50, Width=400 };
            Button confirmation = new Button() { Text = "Ok", Left=350, Width=100, Top=70, DialogResult = DialogResult.OK };
            confirmation.Click += (sender, e) => { prompt.Close(); };
            prompt.Controls.Add(textBox);
            prompt.Controls.Add(confirmation);
            prompt.Controls.Add(textLabel);
            prompt.AcceptButton = confirmation;
    
            return prompt.ShowDialog() == DialogResult.OK ? textBox.Text : "";
        }
        
        public static void question(int op)
        {
            Vector2D v1 = new Vector2D(rnd(50), rnd(55));
            Vector2D v2 = new Vector2D(rnd(50), rnd(55));
            
            String text = "v1 = (" + v1.x.ToString() + ", " + v1.y.ToString() + "), v2 = (" + v2.x.ToString() + ", " + v2.y.ToString() + ")";
            String str = "";
            if (op == 0 || op == 1)
            {
                Vector2D cor_ans = new Vector2D(0, 0);
                if (op == 0)
                {
                    cor_ans = v1 + v2;
                    str = "v1 + v2";
                } else if (op == 1)
                {
                    cor_ans = v1 - v2;
                    str = "v1 - v2";
                }
                double ans_x, ans_y;
                ans_x = Convert.ToDouble(ShowDialog(text + "\nEnter x of " + str, "question"));
                ans_y = Convert.ToDouble(ShowDialog(text + "\nEnter y of " + str, "question"));
                Vector2D ans = new Vector2D(ans_x, ans_y);
                if (ans == cor_ans)
                {
                    MessageBox.Show("Yes! Answer is correct!");
                } else
                {
                    MessageBox.Show("No! Answer is incorrect!");
                }
            } else if (op == 2 || op == 3)
            {
                double cor_ans = 0;
                if (op == 2)
                {
                    cor_ans = dot_prod(v1, v2);
                    str = "v1 * v2";
                } else if (op == 3)
                {
                    cor_ans = cross_prod(v1, v2);
                    str = "v1 x v2";
                }
                double ans;
                ans = Convert.ToDouble(ShowDialog(text + "\nEnter " + str, "question"));
                if (ans == cor_ans)
                {
                    MessageBox.Show("Yes! Answer is correct!");
                } else
                {
                    MessageBox.Show("No! Answer is incorrect!");
                }
            }
            
        }
        static void Main()
        {
            question(0);
            question(1);
            question(2);
            question(3);
        }
    }
}
